package org.andersen.config;

public class ThisIsMyFirstConditionalBean {

}
