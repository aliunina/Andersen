package org.andersen.model.user;

public enum UserStatus {
    ACTIVATED,
    DEACTIVATED
}
