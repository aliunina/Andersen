package org.andersen.model.ticket;

public enum TicketType {
    DAY,
    WEEK,
    MONTH,
    YEAR
}
